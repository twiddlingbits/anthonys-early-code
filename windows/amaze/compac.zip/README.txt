This file contains Compac, a communications package for
the TRS-80 that supports DFT, XMODEM, and other Smart
Terminal features.

Although all of these files were created
on a TRS-80 (except this one), the .pcl files
can be opened and viewed in Word.

Any contact info in the /pcl files is wrong.

My contact info in 1998 is:
Anthony J. Wood
Palo Alto, CA
ajw@best.com

These files are copyrighted by Anthony J. Wood.  It 
is okay to distribute them for non-commercial purposes 
as long as this notice is also distributed.
